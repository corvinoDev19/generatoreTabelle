Generatori GdR – Pacchetto
==========================
Inclusi:


Come usare:
- Apri i file .html con un doppio clic nel browser.
- Non richiedono internet (eccetto per caricare immagini da URL/CDN).
- Esporta/Importa la libreria GIF in JSON se vuoi condividerla tra generatori.

Note:
- File mancanti (non trovati al momento del pacchetto): generatore_scheda_resoconto.html, generatore_barre_hp_pe.html, editor_tecnica_singola_fixed.html